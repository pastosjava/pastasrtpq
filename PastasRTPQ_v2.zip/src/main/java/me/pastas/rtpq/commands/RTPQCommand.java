package me.pastas.rtpq.commands;

import me.pastas.rtpq.PastasRTPQ;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RTPQCommand implements CommandExecutor {

    private final PastasRTPQ plugin;

    public RTPQCommand(PastasRTPQ plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player player)) {
            return true;
        }

        if (args.length == 0) {
            return true;
        }

        switch (args[0].toLowerCase()) {

            case "join" -> plugin.getQueueManager().join(player);

            case "leave" -> plugin.getQueueManager().leave(player);

            case "reload" -> {

                if (!player.hasPermission("pastasrtpq.admin")) {
                    return true;
                }

                plugin.reloadConfig();

                plugin.getMessageManager().send(
                        player,
                        plugin.getConfig().getString("messages.reloaded")
                );
            }
        }

        return true;
    }
}