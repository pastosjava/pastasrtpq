package me.pastas.rtpq;

import me.pastas.rtpq.commands.RTPQCommand;
import me.pastas.rtpq.managers.MessageManager;
import me.pastas.rtpq.managers.QueueManager;
import org.bukkit.plugin.java.JavaPlugin;

public class PastasRTPQ extends JavaPlugin {

    private static PastasRTPQ instance;

    private QueueManager queueManager;
    private MessageManager messageManager;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        messageManager = new MessageManager(this);
        queueManager = new QueueManager(this);

        getCommand("rtpq").setExecutor(new RTPQCommand(this));

        getServer().getConsoleSender().sendMessage(
                messageManager.parse(getConfig().getString("startup.enabled"))
        );
    }

    @Override
    public void onDisable() {
        getServer().getConsoleSender().sendMessage(
                messageManager.parse(getConfig().getString("startup.disabled"))
        );
    }

    public static PastasRTPQ getInstance() {
        return instance;
    }

    public QueueManager getQueueManager() {
        return queueManager;
    }

    public MessageManager getMessageManager() {
        return messageManager;
    }
}