package me.pastas.rtpq.managers;

import me.pastas.rtpq.PastasRTPQ;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import java.util.Random;

public class TeleportManager {

    private final PastasRTPQ plugin;
    private final Random random = new Random();

    public TeleportManager(PastasRTPQ plugin) {
        this.plugin = plugin;
    }

    public void teleportPlayers(Player p1, Player p2) {

        World world = Bukkit.getWorld(
                plugin.getConfig().getString("world")
        );

        int min = plugin.getConfig().getInt("min-distance");
        int max = plugin.getConfig().getInt("max-distance");

        Location safeLoc = null;

        for (int i = 0; i < 100; i++) {

            int x = random.nextInt(max - min) + min;
            int z = random.nextInt(max - min) + min;

            if (random.nextBoolean()) x = -x;
            if (random.nextBoolean()) z = -z;

            int y = world.getHighestBlockYAt(x, z);

            Location loc = new Location(world, x, y + 1, z);

            if (isSafe(loc)) {
                safeLoc = loc;
                break;
            }
        }

        if (safeLoc == null) return;

        Location loc2 = safeLoc.clone().add(5, 0, 0);

        p1.teleport(safeLoc);
        p2.teleport(loc2);

        plugin.getMessageManager().send(
                p1,
                plugin.getConfig().getString("messages.teleported")
        );

        plugin.getMessageManager().send(
                p2,
                plugin.getConfig().getString("messages.teleported")
        );
    }

    private boolean isSafe(Location loc) {

        Block feet = loc.getBlock();
        Block head = loc.clone().add(0, 1, 0).getBlock();
        Block below = loc.clone().subtract(0, 1, 0).getBlock();

        return below.getType().isSolid()
                && feet.getType().isAir()
                && head.getType().isAir();
    }
}