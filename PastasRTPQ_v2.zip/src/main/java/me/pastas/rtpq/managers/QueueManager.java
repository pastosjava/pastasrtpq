package me.pastas.rtpq.managers;

import me.pastas.rtpq.PastasRTPQ;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class QueueManager {

    private final PastasRTPQ plugin;

    private final List<Player> queue = new ArrayList<>();

    public QueueManager(PastasRTPQ plugin) {
        this.plugin = plugin;
    }

    public void join(Player player) {

        if (queue.contains(player)) return;

        queue.add(player);

        plugin.getMessageManager().send(
                player,
                plugin.getConfig().getString("messages.joined")
        );

        if (queue.size() >= 2) {

            Player p1 = queue.get(0);
            Player p2 = queue.get(1);

            queue.remove(p1);
            queue.remove(p2);

            new TeleportManager(plugin).teleportPlayers(p1, p2);

        } else {

            Bukkit.getScheduler().runTaskLater(plugin, () -> {

                if (queue.contains(player)) {

                    Bukkit.broadcast(
                            plugin.getMessageManager().parse(
                                    plugin.getConfig().getString("messages.queue-broadcast")
                            )
                    );
                }

            }, plugin.getConfig().getInt("queue-wait-broadcast-seconds") * 20L);
        }
    }

    public void leave(Player player) {
        queue.remove(player);

        plugin.getMessageManager().send(
                player,
                plugin.getConfig().getString("messages.left")
        );
    }
}