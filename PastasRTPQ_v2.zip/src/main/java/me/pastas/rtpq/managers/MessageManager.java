package me.pastas.rtpq.managers;

import me.pastas.rtpq.PastasRTPQ;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MessageManager {

    private final PastasRTPQ plugin;

    public MessageManager(PastasRTPQ plugin) {
        this.plugin = plugin;
    }

    public Component parse(String message) {
        message = ChatColor.translateAlternateColorCodes('&', message);

        return MiniMessage.miniMessage().deserialize(message);
    }

    public void send(Player player, String message) {

        String mode = plugin.getConfig().getString("display-mode");

        Component component = parse(
                plugin.getConfig().getString("messages.prefix") + message
        );

        if (mode.equalsIgnoreCase("CHAT") || mode.equalsIgnoreCase("BOTH")) {
            player.sendMessage(component);
        }

        if (mode.equalsIgnoreCase("ACTIONBAR") || mode.equalsIgnoreCase("BOTH")) {
            player.sendActionBar(component);
        }
    }

    public void sendConsole(CommandSender sender, String msg) {
        sender.sendMessage(parse(msg));
    }
}